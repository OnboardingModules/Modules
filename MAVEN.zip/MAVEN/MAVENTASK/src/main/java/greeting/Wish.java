package greeting;

public class Wish {

	public String greet(String name)
	{
		return String.format("Hello! How are you,%s",name);
	}
}
