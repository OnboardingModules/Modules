package greeting;


import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class Wishes {

	@BeforeTest
	public static void setUp()
	{
		System.out.println("Before Test");
	}

	@Test(groups = {"smoke","regression"})
	public void greetName()
	{
		String name = "EPAM";
		System.out.println("Name TestCase");

	}
	@Test(groups = {"regression"})
	public void greetLength()
	{
		String name ="EPAM";
		System.out.println("Length TestCase");
		//Assert.assertTrue(wish.greet(name).length()>name.length());
	}

	@Test(groups ={"smoke","regression"})
	public void greetContain()
	{
		String name = "EPAM";
		System.out.println("Contains TestCase");
		//Assert.assertTrue(wish.greet(name).contains("Hello"));
	}

	@Test(groups = {"regression"})
	public void greetContain2(){
		String name ="EPAM";
		System.out.println("Contains TestCase2");
		//Assert.assertTrue(wish.greet(name).contains("How are you"));
	}
}
