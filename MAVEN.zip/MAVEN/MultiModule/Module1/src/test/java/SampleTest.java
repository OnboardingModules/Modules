import org.junit.Test;


public class SampleTest {

	@Test
	public void test()
	{
		System.out.println("Sample TestCase");
	}
}
