import org.junit.Test;


public class SampleTest3 {

	@Test
	public void test3()
	{
		System.out.println("Sample TestCase3");
	}
}
