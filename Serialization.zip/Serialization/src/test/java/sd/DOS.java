package sd;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;


public class DOS {

	private static final ObjectMapper MAPPER = new ObjectMapper();

	public static void main(String[] args) throws JsonProcessingException {

		String URL = "https://jsonplaceholder.typicode.com/posts/100";

		serial ser = RestAssured.given().get(URL).as(serial.class);
		System.out.println(ser.toString());
	}
}
