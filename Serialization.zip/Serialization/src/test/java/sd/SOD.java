package sd;

//import static org.testng.Assert.assertEquals;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;


public class SOD {

	private static final ObjectMapper MAPPER = new ObjectMapper();

	public static void main(String[] args) throws JsonProcessingException {
		serial ser = new serial();
		ser.setId(101);
		ser.setUserId(1);
		ser.setBody("quia et suscipit");
		ser.setTitle("qui est esse");

		String URL = "https://jsonplaceholder.typicode.com/posts";

		String json = MAPPER.writeValueAsString(ser);

		Response response = RestAssured.given().contentType("application/json").
				log().all(true).body(json).post(URL).andReturn();

		//assertEquals(response.getStatusCode(),201,"HTTP MESSAGE");

	}

}
