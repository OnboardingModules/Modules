package org.example;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import org.junit.Test;


public class HT3_Task2 {

	@Test
	public void Task2Get()
	{
		given().baseUri("https://jsonplaceholder.typicode.com").
				when().get("/users").
				then().assertThat().statusCode(200).
				body("name",equalTo("Ervin Howell"));

	}
}
