package org.example;

import static io.restassured.RestAssured.*;
import static org.hamcrest.CoreMatchers.equalTo;

import org.junit.BeforeClass;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;


public class HometaskRest3 {

	@BeforeClass
	public static void setUp()
	{
		RestAssured.baseURI ="https://petstore.swagger.io";
		RestAssured.basePath="/v2";

		RestAssured.requestSpecification = new RequestSpecBuilder().setContentType("application/json").build();
	}

	@Test
	public void Task1()
	{
		Response resposne = given().
				body("{\n" + "  \"id\": 12345,\n" + "  \"category\": {\n" + "    \"id\": 1,\n" + "    \"name\": \"dog\"\n"
				+ "  },\n" + "  \"name\": \"snoopie\",\n" + "  \"photoUrls\": [\n" + "    \"string\"\n" + "  ],\n"
				+ "  \"tags\": [\n" + "    {\n" + "      \"id\": 0,\n" + "      \"name\": \"string\"\n" + "    }\n"
				+ "  ],\n" + "  \"status\": \"pending\"\n" + "}\n").
		when().
				post("/pet");

		String id = resposne.path("id").toString();
		System.out.println("New pet ID "+id);
		String name = resposne.path("name").toString();
		System.out.println("Name is : "+name);
		String status = resposne.path("status").toString();
		System.out.println("Current status is : "+status);

	}

	@Test
	public void Task1Get()
	{
		get("/pet/12345").
				then().statusCode(200);
	}


}
